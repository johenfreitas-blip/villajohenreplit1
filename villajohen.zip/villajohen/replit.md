# Villa Johen

A beachside villa rental landing page built with React, Vite, TypeScript, Tailwind CSS, and shadcn/ui components. Migrated from Lovable to Replit.

## Architecture

- **Framework**: React 18 + Vite + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **Routing**: React Router DOM v6
- **State/Data**: TanStack React Query
- **Forms**: React Hook Form + Zod

## Project Structure

```
src/
  App.tsx           - Root app with routing
  main.tsx          - Entry point
  index.css         - Global styles and Tailwind config
  pages/
    Index.tsx       - Main landing page
    NotFound.tsx    - 404 page
  components/       - UI components (Navbar, HeroSection, etc.)
  hooks/            - Custom React hooks
  lib/              - Utility functions
```

## Running the Project

The app runs on port 5000 via the "Start application" workflow using `npm run dev`.

## Key Notes

- Port changed from 8080 to 5000 for Replit webview compatibility
- `lovable-tagger` plugin is kept in dev dependencies but only runs in development mode
- Single-page landing site for Villa Johen (Portuguese language)
