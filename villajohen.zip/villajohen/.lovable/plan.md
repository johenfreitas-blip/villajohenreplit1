

# Pousada Villa Johen — Landing Page

## Visão Geral
Landing page única, moderna e elegante para a Pousada Villa Johen, com foco em conversão via WhatsApp. Estilo "praia sofisticada" com paleta natural (verde oliva, bege areia, branco quente) e tipografia elegante. Projeto 100% estático, responsivo, com modo claro/escuro.

---

## Seções da Página (ordem de cima para baixo)

### 1. Navbar Fixa
- Logo da pousada à esquerda
- Links de navegação com scroll suave: Acomodações, Diferenciais, Depoimentos, Localização, Contato
- Toggle de modo claro/escuro
- Botão "Reservar pelo WhatsApp" destacado

### 2. Hero Section
- Imagem de fundo em tela cheia (placeholder com visual de praia)
- Headline emocional: "Seu refúgio à beira-mar"
- Subtítulo com copy de conversão
- CTA principal: botão WhatsApp com mensagem pré-preenchida
- Animação suave de entrada (fade + slide up)

### 3. Seção "Sobre a Pousada"
- Breve texto emocional sobre a experiência
- Ícones com destaques: localização, conforto, natureza
- Layout em grid com imagem ao lado

### 4. Seção de Acomodações ⭐
- 3 cards visuais interativos (com hover elegante):
  - **Suíte Simples** — até 3 pessoas, ventilador, frigobar
  - **Suíte com Ar-Condicionado** — até 3 pessoas, ar-condicionado, frigobar
  - **Chalé Completo** — até 5 pessoas, cozinha, quintal, churrasqueira
- Cada card com botão "Conheça a acomodação"
- **Ao clicar**: modal elegante com:
  - Slider/galeria de fotos
  - Lista de comodidades com ícones
  - Capacidade e configuração
  - Botão WhatsApp com mensagem específica por acomodação
- **Destaque visual** para o diferencial da cozinha comunitária (suítes) com ícones de churrasqueira, fogão, geladeira

### 5. Seção de Diferenciais
- Grid de ícones com benefícios: localização privilegiada, cozinha comunitária, churrasqueira, atendimento personalizado, custo-benefício
- Copy emocional focada em experiência, não apenas características
- Animações ao entrar na viewport

### 6. Seção de Depoimentos
- Carrossel animado com depoimentos de hóspedes (conteúdo placeholder)
- Foto, nome e avaliação com estrelas
- Transição suave entre depoimentos

### 7. Seção de Localização
- Mapa embed (placeholder) com endereço
- Instruções de "Como Chegar"
- Destaques de proximidade: praia, comércios, atrações

### 8. Footer
- Informações de contato
- Links rápidos para seções
- Redes sociais
- Copyright

---

## Elementos Globais

- **Botão flutuante de WhatsApp** — fixo no canto inferior direito, sempre visível, com animação de pulso sutil
- **Botão "Voltar ao topo"** — aparece ao rolar para baixo
- **Pop-up de CTA estratégico** — aparece após scroll de 60% da página: "Consultar disponibilidade agora"
- **Animações ao scroll** — fade-in e slide-up sutis em todas as seções
- **Links WhatsApp** — todos com mensagem pré-preenchida contextual

---

## Design System

- **Cores**: Verde oliva (#6B7C5E), Bege areia (#F5F0E8), Branco quente (#FDFBF7), Marrom grafite (#4A4540)
- **Tipografia**: Serifada elegante para títulos (Playfair Display style), sans-serif limpa para corpo
- **Espaçamento generoso**, visual arejado e clean
- **Modo escuro** com tons escuros quentes mantendo a identidade
- **100% responsivo** — mobile-first com experiência premium em ambos

---

## Melhorias Estratégicas Incluídas
- Mensagens WhatsApp pré-preenchidas específicas por acomodação (aumenta conversão)
- Pop-up de disponibilidade com timing inteligente (após engajamento)
- Hierarquia visual que guia o olhar do visitante até o CTA
- Microinterações nos cards para aumentar engajamento e tempo na página

