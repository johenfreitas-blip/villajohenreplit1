import { motion } from "framer-motion";
import { MapPin, ChefHat, Flame, Heart, BadgeDollarSign, Wifi } from "lucide-react";

const items = [
  {
    icon: MapPin,
    title: "Localização Privilegiada",
    desc: "Pertinho da praia, com fácil acesso a comércios e atrações locais.",
  },
  {
    icon: ChefHat,
    title: "Cozinha Comunitária",
    desc: "Prepare suas refeições com toda a praticidade, economizando na hospedagem.",
  },
  {
    icon: Flame,
    title: "Churrasqueira",
    desc: "Momentos especiais ao redor da churrasqueira com quem você ama.",
  },
  {
    icon: Heart,
    title: "Atendimento Personalizado",
    desc: "Acolhimento caloroso e atendimento humano do check-in ao check-out.",
  },
  {
    icon: BadgeDollarSign,
    title: "Custo-Benefício",
    desc: "Experiência premium com preços justos e acessíveis para todos.",
  },
  {
    icon: Wifi,
    title: "Wi-Fi Gratuito",
    desc: "Conectado mesmo no paraíso. Internet disponível em todas as áreas.",
  },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const DifferentialsSection = () => (
  <section id="diferenciais" className="py-20 md:py-28 bg-background">
    <div className="container mx-auto px-4">
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
          Por que escolher a Villa Johen?
        </h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Mais do que uma pousada, uma experiência. Cada detalhe foi pensado
          para transformar sua estadia em memórias inesquecíveis.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {items.map((item, i) => (
          <motion.div
            key={item.title}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className="bg-card rounded-2xl p-8 text-center shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-primary/10 mb-5">
              <item.icon className="text-primary" size={26} />
            </div>
            <h3 className="font-heading text-lg font-bold text-foreground mb-2">
              {item.title}
            </h3>
            <p className="text-muted-foreground text-sm">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default DifferentialsSection;
