import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";

const testimonials = [
  {
    name: "Maria Silva",
    text: "Lugar incrível! A pousada é linda, pertinho da praia e o atendimento é impecável. Voltaremos com certeza!",
    rating: 5,
  },
  {
    name: "Carlos & Ana",
    text: "Passamos o melhor fim de semana da nossa vida. O chalé é espaçoso, a churrasqueira foi perfeita. Super recomendamos!",
    rating: 5,
  },
  {
    name: "Família Souza",
    text: "Excelente custo-benefício! A cozinha comunitária ajudou muito com as crianças. Tudo limpo e organizado.",
    rating: 5,
  },
  {
    name: "Renata Oliveira",
    text: "Ambiente tranquilo e acolhedor. Perfeito para desconectar e relaxar. O contato via WhatsApp facilita tudo!",
    rating: 4,
  },
];

const TestimonialsSection = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((c) => (c + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const prev = () => setCurrent((c) => (c > 0 ? c - 1 : testimonials.length - 1));
  const next = () => setCurrent((c) => (c + 1) % testimonials.length);

  return (
    <section id="depoimentos" className="py-20 md:py-28 bg-secondary/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            O que nossos hóspedes dizem
          </h2>
        </motion.div>

        <div className="max-w-2xl mx-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.4 }}
              className="bg-card rounded-2xl p-8 md:p-10 text-center shadow-sm"
            >
              <div className="flex justify-center gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    className={
                      i < testimonials[current].rating
                        ? "text-yellow-500 fill-yellow-500"
                        : "text-muted"
                    }
                  />
                ))}
              </div>
              <p className="text-foreground/80 text-lg italic mb-6 leading-relaxed">
                "{testimonials[current].text}"
              </p>
              <p className="font-heading font-bold text-foreground">
                {testimonials[current].name}
              </p>
            </motion.div>
          </AnimatePresence>

          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 bg-card rounded-full p-2 shadow-md hover:bg-muted transition-colors"
            aria-label="Anterior"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 bg-card rounded-full p-2 shadow-md hover:bg-muted transition-colors"
            aria-label="Próximo"
          >
            <ChevronRight size={20} />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  i === current ? "bg-primary" : "bg-muted"
                }`}
                aria-label={`Depoimento ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
