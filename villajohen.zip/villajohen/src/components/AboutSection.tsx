import { motion } from "framer-motion";
import { MapPin, Heart, TreePalm } from "lucide-react";
import aboutImg from "@/assets/about-pousada.jpg";

const features = [
  { icon: MapPin, title: "Localização Privilegiada", desc: "Pertinho da praia e de tudo que você precisa" },
  { icon: Heart, title: "Conforto & Acolhimento", desc: "Atendimento personalizado para sua melhor estadia" },
  { icon: TreePalm, title: "Natureza Exuberante", desc: "Rodeada de verde, perfeita para relaxar e recarregar" },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const AboutSection = () => (
  <section className="py-20 md:py-28 bg-background">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          variants={fadeInUp}
        >
          <img
            src={aboutImg}
            alt="Vista da Pousada Villa Johen"
            className="rounded-2xl shadow-lg w-full object-cover aspect-[4/3]"
            loading="lazy"
          />
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
          variants={fadeInUp}
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
            Sobre a Pousada
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-8">
            A Pousada Villa Johen é o lugar onde o mar encontra o aconchego.
            Aqui, cada detalhe foi pensado para proporcionar momentos de paz,
            descanso e conexão com a natureza. Seja em casal, em família ou
            entre amigos, sua experiência será inesquecível.
          </p>
          <div className="space-y-6">
            {features.map((f) => (
              <div key={f.title} className="flex gap-4 items-start">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <f.icon className="text-primary" size={22} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{f.title}</h3>
                  <p className="text-muted-foreground text-sm">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default AboutSection;
