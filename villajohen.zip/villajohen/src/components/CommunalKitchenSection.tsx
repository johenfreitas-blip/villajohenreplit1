import { motion } from "framer-motion";
import aboutImg from "@/assets/about-pousada.jpg"; // Reusing about image or similar

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const CommunalKitchenSection = () => (
  <section className="py-20 md:py-28 bg-secondary/30">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          variants={fadeInUp}
          className="order-2 md:order-1"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
            Cozinha Comunitária
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-8">
            Nossa cozinha comunitária foi pensada para oferecer praticidade e economia aos nossos hóspedes das suítes. 
            Um espaço amplo, arejado e totalmente equipado para que você possa preparar suas refeições com tranquilidade, 
            sentindo-se em casa mesmo estando na praia.
          </p>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Equipada com fogão, geladeira, micro-ondas, churrasqueira e todos os utensílios necessários. 
            É o local perfeito para reunir a família e amigos após um dia de sol.
          </p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
          variants={fadeInUp}
          className="order-1 md:order-2"
        >
          <img
            src={aboutImg}
            alt="Cozinha Comunitária Villa Johen"
            className="rounded-2xl shadow-lg w-full object-cover aspect-[4/3] h-[400px] md:h-[500px]"
            loading="lazy"
          />
        </motion.div>
      </div>
    </div>
  </section>
);

export default CommunalKitchenSection;
