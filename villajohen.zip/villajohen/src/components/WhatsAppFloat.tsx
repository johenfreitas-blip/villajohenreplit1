import { MessageCircle } from "lucide-react";

const WHATSAPP_NUMBER = "5500000000000";
const WHATSAPP_MSG = encodeURIComponent("Olá! Gostaria de mais informações sobre a Pousada Villa Johen.");

const WhatsAppFloat = () => (
  <a
    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
    target="_blank"
    rel="noopener noreferrer"
    className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center shadow-lg whatsapp-pulse transition-colors"
    aria-label="Fale conosco pelo WhatsApp"
  >
    <MessageCircle size={26} />
  </a>
);

export default WhatsAppFloat;
