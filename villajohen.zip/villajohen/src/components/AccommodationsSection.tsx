import { useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  Wind,
  Snowflake,
  Refrigerator,
  Bath,
  ChefHat,
  Flame,
  CookingPot,
  Home,
  Sofa,
  Trees,
  MessageCircle,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import suiteSimples from "@/assets/suite-simples.jpg";
import suiteAr from "@/assets/suite-ar.jpg";
import chaleImg from "@/assets/chale.jpg";

const WHATSAPP_NUMBER = "5511991188653";

interface Accommodation {
  id: string;
  name: string;
  capacity: string;
  image: string;
  images: string[];
  beds: string;
  amenities: { icon: React.ElementType; label: string }[];
  description: string;
  whatsappMsg: string;
  highlight?: string;
}

const accommodations: Accommodation[] = [
  {
    id: "suite-simples",
    name: "Suíte Simples",
    capacity: "Até 3 pessoas",
    image: suiteSimples,
    images: [suiteSimples, suiteSimples, suiteSimples],
    beds: "1 cama de casal + 1 cama de solteiro",
    amenities: [
      { icon: Wind, label: "Ventilador" },
      { icon: Refrigerator, label: "Frigobar" },
      { icon: Bath, label: "Banheiro completo" },
    ],
    description:
      "Aconchegante e prática, ideal para casais ou pequenos grupos que buscam conforto a um excelente custo-benefício.",
    whatsappMsg: "Olá! Gostaria de saber valores e disponibilidade da Suíte Simples.",
    highlight: "Acesso à cozinha comunitária com churrasqueira, fogão e geladeira",
  },
  {
    id: "suite-ar",
    name: "Suíte com Ar-Condicionado",
    capacity: "Até 3 pessoas",
    image: suiteAr,
    images: [suiteAr, suiteAr, suiteAr],
    beds: "1 cama de casal + 1 cama de solteiro",
    amenities: [
      { icon: Snowflake, label: "Ar-condicionado" },
      { icon: Refrigerator, label: "Frigobar" },
      { icon: Bath, label: "Banheiro completo" },
    ],
    description:
      "Todo o conforto da suíte simples com o plus do ar-condicionado para noites ainda mais agradáveis.",
    whatsappMsg: "Olá! Gostaria de saber valores e disponibilidade da Suíte com Ar-Condicionado.",
    highlight: "Acesso à cozinha comunitária com churrasqueira, fogão e geladeira",
  },
  {
    id: "chale",
    name: "Chalé Completo",
    capacity: "Até 5 pessoas",
    image: chaleImg,
    images: [chaleImg, chaleImg, chaleImg],
    beds: "1 cama de casal + 1 cama de solteiro + 1 bicama na sala",
    amenities: [
      { icon: Home, label: "Quarto e sala" },
      { icon: CookingPot, label: "Cozinha completa" },
      { icon: Bath, label: "Banheiro completo" },
      { icon: Sofa, label: "Sala de estar" },
      { icon: Trees, label: "Quintal privativo" },
      { icon: Flame, label: "Churrasqueira" },
    ],
    description:
      "Perfeito para famílias e grupos. Espaço amplo com cozinha, sala, quintal privativo e churrasqueira — sua casa na praia.",
    whatsappMsg: "Olá! Gostaria de saber valores e disponibilidade do Chalé Completo.",
  },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const AccommodationsSection = () => {
  const [selected, setSelected] = useState<Accommodation | null>(null);
  const [imgIdx, setImgIdx] = useState(0);

  const openModal = (acc: Accommodation) => {
    setSelected(acc);
    setImgIdx(0);
  };

  return (
    <section id="acomodacoes" className="py-20 md:py-28 bg-secondary/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nossas Acomodações
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Escolha o espaço perfeito para a sua estadia. Cada acomodação foi
            pensada para oferecer conforto, praticidade e uma experiência única.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {accommodations.map((acc, i) => (
            <motion.div
              key={acc.id}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeInUp}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="group cursor-pointer"
              onClick={() => openModal(acc)}
            >
              <div className="bg-card rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group-hover:-translate-y-1">
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img
                    src={acc.image}
                    alt={acc.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm text-foreground text-xs font-medium px-3 py-1.5 rounded-full flex items-center gap-1">
                    <Users size={14} />
                    {acc.capacity}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-xl font-bold text-foreground mb-2">
                    {acc.name}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {acc.description}
                  </p>
                  {acc.highlight && (
                    <div className="flex items-center gap-2 text-xs text-primary bg-primary/10 px-3 py-2 rounded-lg mb-4">
                      <ChefHat size={14} />
                      {acc.highlight}
                    </div>
                  )}
                  <Button variant="outline" className="w-full">
                    Conheça a acomodação
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Communal kitchen highlight */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 bg-card rounded-2xl p-8 text-center shadow-sm"
        >
          <h3 className="font-heading text-xl font-bold text-foreground mb-3">
            🍳 Cozinha Comunitária — Exclusiva para Suítes
          </h3>
          <p className="text-muted-foreground mb-4 max-w-xl mx-auto">
            Economize e aproveite! Todas as suítes possuem acesso a uma cozinha
            completa com churrasqueira, fogão, geladeira e utensílios.
          </p>
          <div className="flex justify-center gap-8 text-primary">
            <div className="flex flex-col items-center gap-1">
              <Flame size={28} />
              <span className="text-xs text-muted-foreground">Churrasqueira</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <CookingPot size={28} />
              <span className="text-xs text-muted-foreground">Fogão</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <Refrigerator size={28} />
              <span className="text-xs text-muted-foreground">Geladeira</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Accommodation Modal */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-xl p-0 overflow-hidden rounded-2xl border-none">
          {selected && (
            <>
              {/* Image slider */}
              <div className="relative aspect-video bg-muted">
                <img
                  src={selected.images[imgIdx]}
                  alt={selected.name}
                  className="w-full h-full object-cover"
                />
                {selected.images.length > 1 && (
                  <>
                    <button
                      onClick={() => setImgIdx((p) => (p > 0 ? p - 1 : selected.images.length - 1))}
                      className="absolute left-3 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background rounded-full p-2 transition-colors"
                    >
                      <ChevronLeft size={20} />
                    </button>
                    <button
                      onClick={() => setImgIdx((p) => (p < selected.images.length - 1 ? p + 1 : 0))}
                      className="absolute right-3 top-1/2 -translate-y-1/2 bg-background/80 hover:bg-background rounded-full p-2 transition-colors"
                    >
                      <ChevronRight size={20} />
                    </button>
                  </>
                )}
              </div>

              <div className="p-6">
                <h3 className="font-heading text-2xl font-bold text-foreground mb-1">
                  {selected.name}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 flex items-center gap-2">
                  <Users size={14} /> {selected.capacity} — {selected.beds}
                </p>
                
                {/* Image Grid for accommodation */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {selected.images.map((img, idx) => (
                    <div 
                      key={idx} 
                      className={`aspect-square rounded-lg overflow-hidden cursor-pointer border-2 transition-all ${imgIdx === idx ? 'border-primary' : 'border-transparent'}`}
                      onClick={() => setImgIdx(idx)}
                    >
                      <img src={img} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>

                <p className="text-foreground/80 mb-6 text-sm leading-relaxed">{selected.description}</p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
                  {selected.amenities.map((a) => (
                    <div
                      key={a.label}
                      className="flex items-center gap-2 text-sm bg-secondary/70 rounded-lg px-3 py-2"
                    >
                      <a.icon size={16} className="text-primary" />
                      {a.label}
                    </div>
                  ))}
                </div>

                {selected.highlight && (
                  <div className="flex items-center gap-2 text-sm text-primary bg-primary/10 px-4 py-3 rounded-lg mb-6">
                    <ChefHat size={16} />
                    {selected.highlight}
                  </div>
                )}

                <Button
                  asChild
                  className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white"
                >
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(selected.whatsappMsg)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MessageCircle size={18} />
                    Consultar disponibilidade
                  </a>
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default AccommodationsSection;
