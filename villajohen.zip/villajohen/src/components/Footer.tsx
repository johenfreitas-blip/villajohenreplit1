import { MessageCircle, Instagram, Facebook, Mail, Phone } from "lucide-react";

const WHATSAPP_NUMBER = "5511991188653";

const Footer = () => (
  <footer id="contato" className="bg-card border-t border-border py-16">
    <div className="container mx-auto px-4">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Brand */}
        <div>
          <h3 className="font-heading text-2xl font-bold text-primary mb-3">Villa Johen</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Seu refúgio à beira-mar. Conforto, natureza e memórias inesquecíveis.
          </p>
        </div>

        {/* Quick links */}
        <div>
          <h4 className="font-heading font-bold text-foreground mb-3">Navegação</h4>
          <ul className="space-y-2 text-sm">
            {["Acomodações", "Diferenciais", "Cozinha", "Depoimentos", "Localização"].map((l) => (
              <li key={l}>
                <a
                  href={`#${l.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")}`}
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  {l}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-heading font-bold text-foreground mb-3">Contato</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Phone size={14} className="text-primary" />
              (11) 99118-8653
            </li>
            <li className="flex items-center gap-2">
              <MessageCircle size={14} className="text-primary" />
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition-colors"
              >
                WhatsApp
              </a>
            </li>
          </ul>
        </div>

        {/* Social */}
        <div>
          <h4 className="font-heading font-bold text-foreground mb-3">Redes Sociais</h4>
          <div className="flex gap-3">
            <a
              href="https://www.instagram.com/villajohenboicucanga"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-colors"
              aria-label="Instagram"
            >
              <Instagram size={18} className="text-primary" />
            </a>
          </div>
        </div>
      </div>

      <div className="mt-12 pt-6 border-t border-border text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Pousada Villa Johen. Todos os direitos reservados.
      </div>
    </div>
  </footer>
);

export default Footer;
