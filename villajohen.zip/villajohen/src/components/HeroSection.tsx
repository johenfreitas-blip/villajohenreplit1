import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-beach.jpg";

const WHATSAPP_NUMBER = "5511991188653";
const WHATSAPP_MSG = encodeURIComponent("Olá! Gostaria de saber sobre disponibilidade na Pousada Villa Johen.");

const HeroSection = () => (
  <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
    <div
      className="absolute inset-0 bg-cover bg-center"
      style={{ backgroundImage: `url(${heroImg})` }}
    />
    <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60" />

    <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
      <motion.h1
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="font-heading text-5xl md:text-7xl font-bold text-white mb-6 leading-tight"
      >
        Seu refúgio à beira-mar
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="text-lg md:text-xl text-white/90 mb-8 font-body max-w-xl mx-auto"
      >
        Descanse em um paraíso entre o verde e o mar. Conforto, natureza e
        momentos inesquecíveis esperam por você.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
      >
        <Button
          asChild
          size="lg"
          className="gap-2 text-base px-8 py-6 bg-green-600 hover:bg-green-700 text-white border-0"
        >
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageCircle size={20} />
            Reserve pelo WhatsApp
          </a>
        </Button>
      </motion.div>
    </div>

    {/* Scroll indicator */}
    <motion.div
      animate={{ y: [0, 10, 0] }}
      transition={{ repeat: Infinity, duration: 2 }}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 w-6 h-10 rounded-full border-2 border-white/50 flex items-start justify-center p-1.5"
    >
      <div className="w-1.5 h-2.5 bg-white/70 rounded-full" />
    </motion.div>
  </section>
);

export default HeroSection;
