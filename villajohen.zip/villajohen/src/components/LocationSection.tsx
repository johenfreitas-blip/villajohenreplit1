import { motion } from "framer-motion";
import { MapPin, Navigation, ShoppingBag, Waves } from "lucide-react";

const proximities = [
  { icon: Waves, label: "Praia", distance: "15 min a pé | 5 min de carro" },
  { icon: ShoppingBag, label: "Comércios", distance: "5 min a pé" },
  { icon: Navigation, label: "Centro do bairro", distance: "15 min a pé | 5 min de carro" },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const LocationSection = () => (
  <section id="localizacao" className="py-20 md:py-28 bg-background">
    <div className="container mx-auto px-4">
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeInUp}
        transition={{ duration: 0.6 }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
          Localização
        </h2>
        <p className="text-muted-foreground text-lg max-w-xl mx-auto">
          Fácil de chegar, difícil de esquecer.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-10 items-start">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
          transition={{ duration: 0.6 }}
          className="bg-card rounded-2xl overflow-hidden shadow-sm aspect-video"
        >
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.9839447475354!2d-45.5654064246638!3d-23.748114578672522!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94d293d043f1e637%3A0xc3f9829e1c3a6496!2sR.%20Nair%20Marques%20dos%20Santos%2C%20167%20-%20Boi%C3%A7ucanga%2C%20S%C3%A3o%20Sebasti%C3%A3o%20-%20SP%2C%2011618-474!5e0!3m2!1spt-BR!2sbr!4v1715870000000!5m2!1spt-BR!2sbr" 
            className="w-full h-full border-0" 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-6"
        >
          <div>
            <h3 className="font-heading text-xl font-bold text-foreground mb-2 flex items-center gap-2">
              <MapPin size={20} className="text-primary" />
              Endereço
            </h3>
            <p className="text-muted-foreground">
              Rua Nair Marques dos Santos, 167 — Boiçucanga, São Sebastião, SP
              <br />
              CEP: 11618-474
            </p>
          </div>

          <div>
            <h3 className="font-heading text-xl font-bold text-foreground mb-3">
              Como Chegar
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Acesso fácil pela rodovia principal. Ao chegar na cidade, siga
              pela avenida beira-mar até o número 123. Estacionamento gratuito
              disponível para hóspedes.
            </p>
          </div>

          <div>
            <h3 className="font-heading text-xl font-bold text-foreground mb-3">
              O que há por perto
            </h3>
            <div className="space-y-3">
              {proximities.map((p) => (
                <div key={p.label} className="flex items-center gap-3 text-foreground/80">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <p.icon size={18} className="text-primary" />
                  </div>
                  <div>
                    <span className="font-medium">{p.label}</span>
                    <span className="text-muted-foreground text-sm ml-2">— {p.distance}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default LocationSection;
