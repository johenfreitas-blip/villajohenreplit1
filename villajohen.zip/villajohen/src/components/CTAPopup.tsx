import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const WHATSAPP_NUMBER = "5500000000000";
const WHATSAPP_MSG = encodeURIComponent("Olá! Gostaria de consultar disponibilidade na Pousada Villa Johen.");

const CTAPopup = () => {
  const [show, setShow] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (dismissed) return;
    const onScroll = () => {
      const scrollPercent = window.scrollY / (document.body.scrollHeight - window.innerHeight);
      if (scrollPercent > 0.6 && !dismissed) setShow(true);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, [dismissed]);

  const dismiss = () => {
    setShow(false);
    setDismissed(true);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 60 }}
          className="fixed bottom-24 right-6 z-40 bg-card rounded-2xl shadow-xl p-6 max-w-sm border border-border"
        >
          <button
            onClick={dismiss}
            className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"
            aria-label="Fechar"
          >
            <X size={18} />
          </button>
          <h3 className="font-heading text-lg font-bold text-foreground mb-2">
            Consultar disponibilidade agora? 🏖️
          </h3>
          <p className="text-muted-foreground text-sm mb-4">
            Garanta sua estadia dos sonhos. Fale direto com a gente pelo WhatsApp!
          </p>
          <Button
            asChild
            className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white"
          >
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle size={18} />
              Falar no WhatsApp
            </a>
          </Button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CTAPopup;
