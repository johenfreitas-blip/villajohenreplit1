import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import AccommodationsSection from "@/components/AccommodationsSection";
import CommunalKitchenSection from "@/components/CommunalKitchenSection";
import DifferentialsSection from "@/components/DifferentialsSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import LocationSection from "@/components/LocationSection";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import ScrollToTop from "@/components/ScrollToTop";
import CTAPopup from "@/components/CTAPopup";

const Index = () => {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <AccommodationsSection />
      <div id="cozinha">
        <CommunalKitchenSection />
      </div>
      <DifferentialsSection />
      <TestimonialsSection />
      <LocationSection />
      <Footer />
      <WhatsAppFloat />
      <ScrollToTop />
      <CTAPopup />
    </main>
  );
};

export default Index;
